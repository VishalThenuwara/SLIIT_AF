
const price = [
    {
        "_id": 0,
        "name": "Any",
        "array": []
    },
    {
        "_id": 1,
        "name": "Rs.0 to Rs.500",
        "array": [0, 499]
    },
    {
        "_id": 2,
        "name": "Rs.500 to Rs.1000",
        "array": [500, 999]
    },
    {
        "_id": 3,
        "name": "Rs.1000 to Rs.1500",
        "array": [1000, 1499]
    },
    {
        "_id": 4,
        "name": "Rs.1500 to Rs.2000",
        "array": [1500, 1999]
    },
    {
        "_id": 5,
        "name": "More than Rs.2000",
        "array": [2000, 1500000]
    }
]



const continents = [
    {
        "_id": 1,
        "name": "Ladies"
    },
    {
        "_id": 2,
        "name": "Gents"
    },
    {
        "_id": 3,
        "name": "Kids"
    },
    {
        "_id": 4,
        "name": "Ladies Shoes"
    },
    {
        "_id": 5,
        "name": "Accessories"
    },
    {
        "_id": 6,
        "name": "Cosmetics"
    },
    {
        "_id": 7,
        "name": "Bags"
    }
]


export {
    price,
    continents
}