import React from 'react';

import './App.css';
import Register from './Components/Register';

import Login from './Components/Login';
import{BrowserRouter,Switch,Route}from 'react-router-dom';
import NavBar from './Components/NavBar';

import CatergoryArray from './Components/CatergoryArray';



function App() {
  return (
    <div>

    <NavBar/> 


     <BrowserRouter>
     <Switch>
       <Route path="/Login"> <Login/></Route>
       <Route path="/Register"> <Register/></Route>
       <Route path ="/CatergoryArray"><CatergoryArray/></Route>
       </Switch>
       </BrowserRouter>
     
     
     
     </div>
  );
}

export default App;
