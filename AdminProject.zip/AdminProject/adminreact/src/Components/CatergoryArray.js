import React, { Component } from 'react'
import AddCatergory from './AddCatergory'

class CatergoryArray extends Component {
constructor(props) {
    super(props)

    this.state = {
         array:[]
    }
}

HandleSubmit = arrays => {
    this.setState({
    array: [...this.state.array, arrays]
    });
    console.log("added");
}


    render() {
        return (
            <div className='wrapper'>
               <div>
                <AddCatergory onFormSubmit={this.HandleSubmit}/>
                <List array={this.state.array}/>
                </div>
                
                
            </div>
        );
    }
}

const List =(props)=>{
        const citem =props.array.map((additem,index)=>{
            return<Additem content={additem} key={index} id={index}/>
        })
        return(
            <div className='list-wrapper'>
               {citem} 
            </div>
        );
}

const Additem=(props)=>{
    return(
        <div className="list-item">
        {props.content}
    </div>
    );
    

}

export default CatergoryArray
