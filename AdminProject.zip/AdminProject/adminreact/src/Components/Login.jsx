import React,{Component} from 'react';
import './LoginStyle.css';

class Login extends Component{


onSubmitHandler=()=>{
  alert(JSON.stringify(this.state))
}


onChangeHandler =(e) =>{
 const{name,value}=e.target;

 this.setState({
   [name]:value
 })

}

render(){
  return(
<div className="Login-parent">

<div className="login-name">
<h1 className="title-login"> LOGIN</h1>
</div>
<div className="login-form">

 <form onSubmit={this.onSubmitHandler}>
        <div className="form-group">
          <label htmlFor="exampleInputEmail1">Email address</label>
          <input name="email" onChange={this.onChangeHandler} type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
          
        </div>
        <div className="form-group">
          <label htmlFor="exampleInputPassword1">Password</label>
          <input name="Password"onChange={this.onChangeHandler}  type="password" className="form-control" id="exampleInputPassword1"/>
        </div>
        
        <button type="submit" className="btn button-submit">Login</button>
      </form>
</div>



</div>
  );
}

}
export default Login;