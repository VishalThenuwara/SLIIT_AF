import React,{Component} from 'react';


export class AddCatergory extends Component {

constructor(props) {
    super(props)

    this.state = {
         catergory:''
    }
}

onChangeHandler=(e)=>{
    this.setState({
        catergory:e.target.value
    })
    console.log(e.target.value);
}

submitHandler=(e)=>{
e.preventDefault();
if(this.state.catergory==='')return;
this.props.onFormSubmit(this.state.catergory)
this.setState({catergory:''})
}



    render() {
        return (
            <div>
                <form onSubmit={this.submitHandler}>
                    <div >
                        <input type="text" className="catergory-list" placeholder="Enter catergory type" value={this.state.catergory} onChange={this.onChangeHandler} ></input>
                        <button>Add</button>
                    </div>

                </form>
            </div>
        )
    }
}

export default AddCatergory

 
 

