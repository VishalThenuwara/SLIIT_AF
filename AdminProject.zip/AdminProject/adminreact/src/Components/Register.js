import React, { Component } from 'react';
import './Register.css';
import axios from 'axios';


class Register extends Component {
  constructor(props) {
    super(props);
    this.onchangeUserName = this.onchangeUserName.bind(this);
    this.OnchangePassword = this.OnchangePassword.bind(this);
    this.onchangeEmail = this.onchangeEmail.bind(this);
    this.onSubmit = this.onSubmit.bind(this);



    this.state = {
      username: '',
      password: '',
      email: '',
      passwordError:'',


    }
  }

  validate=()=>{
    let passwordError="";

    if(!this.state.password.includes(5)){
      passwordError="Include more than 5 Characters";
      
    }
    if(passwordError){
      this.setState({passwordError})
      return false;

    }
    return true;
  }


  onchangeUserName(e) {
    this.setState({
      username: e.target.value
    });
  }
  OnchangePassword(e) {
    this.setState({
      password: e.target.value
    })
  }
  onchangeEmail(e) {
    this.setState({
      email: e.target.value
    })
  }
  onSubmit(e) {

    e.preventDefault();
    
    const obj = {//create an object 
      username: this.state.username,
      password: this.state.password,
      email: this.state.email
    };
    axios.post('http://localhost:4000/business/add', obj)//pass the object
      .then(res => console.log(res.data));

    this.setState({ username: '', password: '', email: '' })//back to null values
  }



  render() {
    return (

      <div className="Login-parent">

        <div className="login-name">
          <h1 className="title-login">SignUp</h1>
        </div>
        <div className="login-form">
          <form onSubmit={this.onSubmit} method="POST" action="send">
            <div className="form-group">
              <label>Username</label>
              <input type="text" className="form-control" placeholder="Username" name="username" value={this.state.username} required onChange={this.onchangeUserName} />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input type="password" className="form-control" placeholder="Password" name="password" value={this.state.password} required onChange={this.OnchangePassword} />
            </div>

            <div className="form-group">
              <label>Email</label>
              <input type="email" className="form-control" placeholder="enter email" name="email" value={this.state.email} onChange={this.onchangeEmail} />
              
            </div>

            <button type="submit" className="btn btn-primary">Submit</button>
           
          </form>


        </div>
      </div>
    );

  }
}

export default Register;