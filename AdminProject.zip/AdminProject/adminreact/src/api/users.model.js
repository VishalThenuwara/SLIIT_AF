const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const Schema1 = mongoose.Schema;

let Business = new Schema({
      username: { type: String },
      password: { type: String },
      email: { type: String }
}, {
      collection: 'business'
});

let Business1 = new Schema1({
      catergory:{type:String}
}, {
      collection: 'CatergoryNames'
});

module.exports=mongoose.model('Business1',Business1)

module.exports = mongoose.model('Business', Business)
