module.exports = {     DB: 'mongodb://localhost:27017/StoreManager' }
module.exports= {DB: 'mongodb://localhost:27017/CatergoryNames'}