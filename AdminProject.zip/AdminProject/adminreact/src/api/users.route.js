const express = require('express');
const UsersRoutes = express.Router();


const nodemailer = require('nodemailer');

// Require Business model in our routes module 
let  Business= require('./users.model');

// Defined store route
UsersRoutes.route('/add').post(function (req, res) {
   let  business = new Business(req.body);
   business.save()
      .then(business=> {
         res.status(200).json({ 'business': 'users are added successfully' });
      })
      .catch(err => {
         res.status(400).send("unable to save to database");
      });

      let email = req.body.email;
      let username =req.body.username;

      const output = `
          <p>You have a successfully logged by the admin</p>
          <h3> Details</p>
          <ul>

            <li>Email: ${username}</li>
            <li>Email: ${email}</li>
              
              
              
          </ul>
      `;
  
      let transporter = nodemailer.createTransport({
          host: "smtp.gmail.com",
          port: 587,
          secure: false, // true for 465, false for other ports
          auth: {
              user: 'githmarpa@gmail.com', // generated ethereal user
              pass: '1234567#@' // generated ethereal password
          }
      });
  
      // send mail with defined transport object
      let info = transporter.sendMail({
          from: '"Admin" <githmarpa@gmail.com>', // sender address
          to: req.body.email, // list of receivers
          subject: "SignUp successfully", // Subject line
          text: "Hello world?", // plain text body
          html: output // html body
      });
  
      console.log("Message sent: %s", info.messageId);
      console.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  
});

// Defined get data(index or listing) route 
UsersRoutes.route('/').get(function (req, res) {
   Business.find(function (err, business) {
      if (err) {
         console.log(err);
      } else {
         res.json(business);
      }
   });
});

module.exports = UsersRoutes; 