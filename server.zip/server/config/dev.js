module.exports = {
    mongoURI: 'mongodb+srv://project:project123@cluster0-qzrwh.mongodb.net/test?retryWrites=true&w=majority'
}